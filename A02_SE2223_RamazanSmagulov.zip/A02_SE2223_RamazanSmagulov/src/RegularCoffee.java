public class RegularCoffee implements Coffee {
    @Override
    public String getDescription() {
        return "Regular Coffee";
    }

    @Override
    public double cost() {
        return 5.0;
    }
}

// Espresso.java


// Latte.java
