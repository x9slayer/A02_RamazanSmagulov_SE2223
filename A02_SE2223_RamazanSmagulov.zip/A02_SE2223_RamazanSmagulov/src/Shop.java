import java.util.Scanner;

public class Shop {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to the Coffee Shop!");
        System.out.println("Choose a coffee type:");
        System.out.println("1. Regular");
        System.out.println("2. Espresso");
        System.out.println("3. Latte");

        int coffeeType = scanner.nextInt();
        Coffee coffee;

        switch (coffeeType) {
            case 1:
                coffee = new RegularCoffee();
                break;
            case 2:
                coffee = new Espresso();
                break;
            case 3:
                coffee = new Latte();
                break;
            default:
                System.out.println("Invalid choice. Exiting.");
                scanner.close();
                return;
        }

        System.out.println("Choose additions:");
        System.out.println("1. Add Milk");
        System.out.println("2. Add Sugar");
        System.out.println("3. Add both Milk and Sugar");
        System.out.println("0. Skip");

        int additionType = scanner.nextInt();

        switch (additionType) {
            case 1:
                coffee = new MilkDecorator(coffee);
                break;
            case 2:
                coffee = new SugarDecorator(coffee);
                break;
            case 3:
                coffee = new SugarDecorator(new MilkDecorator(coffee));
                break;
            case 0:
                // Skip additions
                break;
            default:
                System.out.println("Invalid choice. Exiting.");
                scanner.close();
                return;
        }

        System.out.println("Your customized coffee: " + coffee.getDescription() + " - $" + coffee.cost());

        scanner.close();
    }
}
