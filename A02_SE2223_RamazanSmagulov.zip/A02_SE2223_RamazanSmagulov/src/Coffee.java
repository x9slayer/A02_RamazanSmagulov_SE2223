public interface Coffee {
    String getDescription();
    double cost();
}